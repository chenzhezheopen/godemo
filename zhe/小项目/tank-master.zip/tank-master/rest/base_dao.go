package rest

type BaseDao struct {
	Bean
}



