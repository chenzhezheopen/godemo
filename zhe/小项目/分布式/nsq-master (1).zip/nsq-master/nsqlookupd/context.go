package nsqlookupd

type Context struct {
	nsqlookupd *NSQLookupd
}
